# Requirements – Faction Renown Tracking

## Decisions from clarification
- Storage: Journal Entry Page sub-type backed by a DataModel.
- Renown: numeric points with per-level thresholds; 8 levels from Infamous to Paragon.
- Leader: single Actor now; data stored as a `leadership` list of `{ actorUuid, rank }` so more ranks can be added later.
- Tracked actors: any Actor.
- Permissions: GM edits everything; players can view factions where one of their owned actors is tracked.
- UI: Journal sidebar button + faction page sheet, and a standalone Faction Manager (ApplicationV2).
- Renown change history and chat notification on level change are included.
- Test framework: Vitest.

## Assumptions (please confirm or change)
- Points range -100 to 100, clamped, initial 0.
- Thresholds (minimum points): Infamous -100, Hated -75, Disliked -40, Neutral -10, Liked 10, Respected 40, Revered 75, Paragon 90.
- Default logo: `icons/svg/mystery-man.svg`.

## Requirements
| ID | Requirement | Acceptance criteria |
|----|-------------|---------------------|
| REQ-001 | A faction has a name, logo, description, leadership and goals. | `createFaction` returns all fields; description defaults to "". |
| REQ-002 | Faction name is required. | Empty/whitespace name throws; name is trimmed. |
| REQ-003 | Logo falls back to a default icon. | Missing/blank logo yields the default path. |
| REQ-004 | An Actor can be assigned as leader (single, extensible by rank). | `setLeader` stores `{actorUuid, rank:"leader"}`; replaces previous leader; `null` clears; other ranks preserved. |
| REQ-005 | Goals have title, description, completed flag. | `addGoal` creates goal with unique id, `completed:false`; blank title throws. |
| REQ-006 | Goals can be completed/uncompleted and removed. | `toggleGoal` flips state; `removeGoal` removes it; unknown id throws. |
| REQ-007 | Actors can be added to a faction to track renown (dropping an Actor). | `addMember` adds with 0 points; duplicates ignored; `removeMember` removes. |
| REQ-008 | Renown levels map from points via thresholds. | `getRenownLevel` returns correct key at every boundary. |
| REQ-009 | Renown is clamped to -100..100. | `clampRenown`/`setRenown` never exceed bounds; non-finite rejected. |
| REQ-010 | Renown changes are logged. | `setRenown` appends `{actorUuid, from, to, reason, user, timestamp}`. |
| REQ-011 | Level changes are reported for chat notification. | `setRenown` result has `levelChange {from,to}` only when level key changes, else `null`. |
| REQ-012 | Only tracked actors can have renown changed. | `setRenown` on non-member throws. |
| REQ-013 | GM edits; players view only factions tracking an actor they own. | `canEdit` true only for GM; `canView` per rule. |
| REQ-014 | Logic functions are pure (inputs not mutated). | Original faction object deep-equals snapshot after calls. |

## Traceability
| Requirement | Test file |
|---|---|
| REQ-001–007, 010–012, 014 | tests/faction.test.mjs |
| REQ-008–009 | tests/renown.test.mjs |
| REQ-013 | tests/permissions.test.mjs |

Not unit-testable (manual/in-Foundry): drag-drop UI, file picker, sidebar button, chat message rendering, DataModel registration. Gap noted; only their pure logic is covered.

## Intended modules (for FoundryModuleDeveloper)
- `scripts/renown.mjs`: `RENOWN_LEVELS`, `RENOWN_MIN`, `RENOWN_MAX`, `clampRenown`, `getRenownLevel`
- `scripts/faction.mjs`: `DEFAULT_FACTION_IMG`, `createFaction`, `setLeader`, `addGoal`, `toggleGoal`, `removeGoal`, `addMember`, `removeMember`, `setRenown(faction, actorUuid, points, {reason, user, timestamp}) -> { faction, levelChange }`
- `scripts/permissions.mjs`: `canEdit({isGM})`, `canView({isGM, ownedActorUuids}, faction)`

## Quest tracking and faction organization

The requirements below supersede the single-leader UI in REQ-004. Existing
renown tracking, including its data, history, permissions, and behavior, remains
independent of organizational membership. Existing leader assignments need not
be migrated to roles or members. The current `members` data in the faction
model refers to renown tracking, not the new organizational membership.

| ID | Requirement and rationale | Acceptance criteria |
|---|---|---|
| REQ-015 | Provide a dedicated quest manager so GMs can track quests separately from factions. | A Quests button appears beside Factions in the Journal sidebar. A GM can create, edit, and delete quests in the manager. The manager is GM-only. |
| REQ-016 | Capture quest details. | A quest requires a nonblank title and description and at least one giver: an Actor, a faction, or both. Its icon is optional and uses a default when omitted. |
| REQ-017 | Represent progress without imposing a workflow. | States are Offered, Rejected, Accepted, In Progress, Completed, and Failed. New quests start Offered. A GM may change between any states; a non-GM cannot change state. |
| REQ-018 | Describe optional rewards and consequences. | A reward may combine XP, item entries with quantities, and system currencies, or be empty. A failure consequence is optional and is not automated. |
| REQ-019 | Record interested parties separately from givers. | A quest may have any number of Actor and faction observers; each is a link to its sheet. A giver is not an observer. Observers are optional. |
| REQ-020 | Relate quests without controlling their progression. | A GM can add and remove links; links are bidirectional, cannot point to the same quest, and have no prerequisite or automatic state effects. |
| REQ-021 | Avoid dangling relationships. | Deleting a quest removes its relationships from other quests without changing their states or deleting them. |
| REQ-022 | Show faction involvement. | A faction's Quests section lists quests for which it is a giver or observer. Players who can view the faction can see quest names and links and open quest details read-only; they cannot edit quests. |
| REQ-023 | Create quests in faction context. | A faction window offers a GM-only Create Quest button. The GM chooses whether and how to associate the originating faction as giver or observer; normal giver validation still applies. |
| REQ-024 | Confirm reward distribution on completion. | On changing a quest to Completed, show an assignment window. Cancel leaves quest and rewards unchanged. A quest without rewards may complete without assignments; otherwise the GM assigns recipients. |
| REQ-025 | Award XP to selected actors. | The GM selects recipient actors. Each selected actor receives the full specified XP amount, not a split share. |
| REQ-026 | Award items flexibly. | Each item entry has a quantity. The GM may distribute copies among different actors; items are copied, not transferred. It is not necessary to assign every copy. |
| REQ-027 | Divide system currency fairly. | The GM selects recipient actors. Divide each currency amount evenly, rounding down per recipient; convert any remainder successively to available lower denominations and divide again. Record any final indivisible remainder in the quest for adjudication. |
| REQ-028 | Support the selected game systems. | Reward automation supports Dungeons & Dragons 5e, Shadowdark, Pathfinder 2e, and Cosmere RPG using their system-specific actor and currency data. The GM chooses recipients. An unsupported system or actor unable to receive a reward is handled as an award failure. |
| REQ-029 | Preserve a clear reward audit and avoid duplicate payouts. | Record all reward assignments and failures on the quest. If an award fails, notify the GM, record the error for manual adjudication, and leave the quest Completed; successful awards remain recorded. Rewards are awarded only once, even if the state later leaves and re-enters Completed. Reward definitions cannot be edited after first completion. |
| REQ-030 | Let GMs define faction structure. | A GM can add, rename, delete, and drag roles to reorder them. The list order is the only hierarchy; roles have no parent relationships. |
| REQ-031 | Assign organizational membership. | A GM can add and remove Actors as members and assign each member exactly one role in a given faction. Reassigning replaces the old role. The same Actor can hold different roles in different factions. |
| REQ-032 | Reorder roles and reassign members intuitively. | Dragging a role moves it together with its displayed member list. Dragging a member to a different role reassigns it; dragging within its current role has no effect. |
| REQ-033 | Prevent orphaned organizational members. | Before deleting a populated role, the GM chooses one other role for all affected members. If no other role exists, deletion is prohibited. |
| REQ-034 | Keep organization separate from reputation. | Organizational membership has its own section, apart from renown. Adding, removing, or reassigning members does not alter renown tracking or history, and renown operations do not alter organizational membership. |
| REQ-035 | Restrict organizational changes. | Only a GM can manage roles and organizational members. Existing faction-view permissions continue to depend on renown tracking, not organizational membership. |

### Test design and traceability

Test names reference requirement IDs. The new tests define proposed pure-logic
contracts, rather than asserting a particular Foundry UI implementation:

- `scripts/quest.mjs`: `createQuest`, `setQuestState`, `addObserver`,
  `addQuestRelation`, `removeQuestRelation`, `deleteQuest`, and
  `questsForFaction`. Relationship functions operate on arrays of quest objects.
- `scripts/quest-rewards.mjs`: `splitCurrency`, `completeQuest`, and `updateRewards`.
  `completeQuest` accepts injected reward-application callbacks so error and
  duplicate-award behavior can be tested without Foundry documents.
- `scripts/faction-organization.mjs`: `addRole`, `renameRole`, `moveRole`,
  `deleteRole`, `assignMember`, `removeMember`, and `moveMember`.

The Foundry interaction cases below remain integration/manual coverage gaps;
passing pure-logic tests alone does not establish those behaviors.

| Requirement | Automated test cases | Additional Foundry integration or manual cases |
|---|---|---|
| REQ-015 | — | Verify sidebar button position, manager access, and quest CRUD as GM and player. |
| REQ-016 | `tests/quest.test.mjs`: required fields, giver combinations, default icon | Create and edit through quest forms; verify Actor/faction links and icon picker. |
| REQ-017 | `tests/quest.test.mjs`: default, allowed transitions, permission | Check all states and player controls in both manager and sheet. |
| REQ-018 | `tests/quest.test.mjs`: combined/empty rewards and optional consequence | Verify controls and no consequence automation on failure. |
| REQ-019 | `tests/quest.test.mjs`: observer links and giver exclusion | Open Actor and faction observer links. |
| REQ-020 | `tests/quest.test.mjs`: bidirectional add/remove and self-link rejection | Verify relationship controls and no automatic progression. |
| REQ-021 | `tests/quest.test.mjs`: delete relationship cleanup | Delete a linked quest in Foundry and verify surviving quests. |
| REQ-022 | `tests/quest.test.mjs`: giver/observer faction selection | Verify faction listing and player read-only links, including document permissions. |
| REQ-023 | — | Create from a faction with each association choice; validate missing giver and hide button for players. |
| REQ-024 | `tests/quest-rewards.test.mjs`: cancel and empty rewards | Verify popup, required recipient assignment, cancel, and actual document persistence. |
| REQ-025 | `tests/quest-rewards.test.mjs`: full XP per selected actor | Verify XP updates against each supported system's actor schema. |
| REQ-026 | `tests/quest-rewards.test.mjs`: split copies and leave copies unassigned | Verify copied embedded items and quantities in each supported system. |
| REQ-027 | `tests/quest-rewards.test.mjs`: conversion, final remainder | Verify system denomination definitions and persistent actor balances in all four systems. |
| REQ-028 | — | Exercise XP, items, and every supported currency on each of the four systems; test unsupported systems and incompatible actors as failures. |
| REQ-029 | `tests/quest-rewards.test.mjs`: failures, audit, repeat completion, reward lock | Verify notification, durable notes and updates, including failure after a partial award. |
| REQ-030 | `tests/faction-organization.test.mjs`: role create/rename/reorder | Verify GM controls and role drag-and-drop. |
| REQ-031 | `tests/faction-organization.test.mjs`: assign/reassign/remove and independent factions | Verify Actor drop, selection, and persistence. |
| REQ-032 | `tests/faction-organization.test.mjs`: role move and member reassignment/no-op | Verify drag behavior and member list placement. |
| REQ-033 | `tests/faction-organization.test.mjs`: reassignment and last-role deletion | Verify reassignment prompt and blocked deletion. |
| REQ-034 | `tests/faction-organization.test.mjs`: renown and membership independence | Verify separate sections and preservation of existing data/history. |
| REQ-035 | `tests/faction-organization.test.mjs`: GM-only management and renown-based visibility | Verify permissions on faction sheets and manager for GM and player. |

Integration gaps: REQ-015, REQ-023, and REQ-028 currently have no automated
test. All other requirements also have the Foundry-specific gaps listed above.
Do not treat the proposed unit contracts as a substitute for system integration.

### Integration test cases

- **REQ-015-INT-01:** As GM, open Quests from the Journal sidebar beside Factions;
  create, edit, and delete a quest. Verify a player cannot access the manager.
- **REQ-023-INT-01:** From a faction window, create quests with the faction as
  giver and as observer. Verify a quest without a giver cannot be saved and a
  player does not see a Create Quest button.
- **REQ-028-INT-01:** In each of D&D 5e, Shadowdark, Pathfinder 2e, and Cosmere
  RPG, complete a quest with XP, copied items, and each available currency;
  verify the selected Actors' actual document values and currency conversions.
- **REQ-028-INT-02:** In an unsupported system, or with an Actor unable to
  receive a reward, confirm completion, GM error notification, and a persistent
  failure entry identifying the reward and recipient.
- **REQ-029-INT-01:** Interrupt the client during reward distribution after an
  Actor update. On reopening the quest, confirm that no reward is automatically
  granted a second time and that an unfinished assignment is visible for manual
  adjudication. Also test concurrent completion attempts from two GM clients.
