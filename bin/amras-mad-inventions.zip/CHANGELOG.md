# Changelog

## 0.2.0
- Add quest tracking, faction quest links, and quest reward assignments.
- Add ordered faction roles and organizational membership independent of renown.

## 0.1.0
- Faction renown tracking: `amras-mad-inventions.faction` Journal Entry Page type with a DataModel.
- Faction page sheet and standalone Faction Manager (Journal sidebar button).
- Leader, goals, tracked Actors with renown (-100..100, 8 levels), history log and chat notification on level change.
- GM edits; players see factions where they own a tracked Actor.

## 0.0.1
- Initial module scaffold.
