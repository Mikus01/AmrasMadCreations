import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

let buildQuestContext, QuestPageSheet, QuestManager, buildFactionQuestSection, cleanupQuestRelations;

beforeAll(async () => {
  const Base = class {};
  vi.stubGlobal("foundry", {
    applications: { api: {
      ApplicationV2: Base, DocumentSheetV2: Base, HandlebarsApplicationMixin: base => base, DialogV2: class {}
    } },
    data: { fields: {} },
    abstract: { TypeDataModel: Base },
    utils: { deepClone: structuredClone }
  });
  ({ buildQuestContext, QuestPageSheet } = await import("../scripts/quest-sheet.mjs"));
  ({ QuestManager, buildFactionQuestSection, cleanupQuestRelations } = await import("../scripts/quest-manager.mjs"));
});

beforeEach(() => {
  vi.stubGlobal("game", {
    user: { isGM: false },
    actors: { contents: [] },
    journal: { contents: [] },
    i18n: { localize: key => key }
  });
  vi.stubGlobal("fromUuidSync", () => null);
});

function page(uuid, relatedQuestIds = []) {
  return {
    uuid,
    name: uuid,
    type: "amras-mad-inventions.quest",
    system: {
      icon: "icon.svg",
      description: "Description",
      giver: { actorUuid: "", factionUuid: "" },
      state: "offered",
      rewards: { xp: 0, items: [], currency: {} },
      consequence: "",
      observers: [],
      relatedQuestIds,
      rewardAudit: [],
      rewardsGranted: false,
      rewardsLocked: false,
      rewardRemainder: {}
    }
  };
}

describe("quest UI integration", () => {
  it("only exposes related quest links to players", () => {
    const current = page("quest-a", ["quest-b"]);
    const context = buildQuestContext(current, {
      relatedPages: [current, page("quest-b"), page("quest-c")]
    });
    expect(context.editable).toBe(false);
    expect(context.relatedQuests.map(q => q.uuid)).toEqual(["quest-b"]);
  });

  it("registers editing actions on both the manager and quest sheet", () => {
    for (const action of ["pickQuestIcon", "saveQuest", "addItemRow", "removeItemRow",
      "addCurrencyRow", "removeCurrencyRow", "addObserverRow", "removeObserverRow"]) {
      expect(QuestPageSheet.DEFAULT_OPTIONS.actions[action]).toBeTypeOf("function");
      expect(QuestManager.DEFAULT_OPTIONS.actions[action]).toBeTypeOf("function");
    }
  });

  it("shows GM-only faction quest creation controls", () => {
    expect(buildFactionQuestSection(null).canCreateQuest).toBe(false);
    game.user.isGM = true;
    expect(buildFactionQuestSection(null).canCreateQuest).toBe(true);
  });

  it("cleans up deleted quest references without altering unrelated links", async () => {
    game.user.isGM = true;
    const survivor = page("quest-b", ["quest-a", "quest-c"]);
    survivor.update = vi.fn().mockResolvedValue(undefined);
    game.journal.contents = [{ pages: { contents: [survivor] } }];
    await cleanupQuestRelations(["quest-a"]);
    expect(survivor.update).toHaveBeenCalledWith({ "system.relatedQuestIds": ["quest-c"] });
  });
});
